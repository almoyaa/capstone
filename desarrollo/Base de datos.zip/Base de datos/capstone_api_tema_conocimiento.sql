-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: capstone
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `api_tema_conocimiento`
--

DROP TABLE IF EXISTS `api_tema_conocimiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_tema_conocimiento` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tema_id` int NOT NULL,
  `conocimiento_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_tema_conocimiento_tema_id_conocimiento_id_af095d24_uniq` (`tema_id`,`conocimiento_id`),
  KEY `api_tema_conocimient_conocimiento_id_c9d2e2ed_fk_api_conoc` (`conocimiento_id`),
  CONSTRAINT `api_tema_conocimient_conocimiento_id_c9d2e2ed_fk_api_conoc` FOREIGN KEY (`conocimiento_id`) REFERENCES `api_conocimiento` (`id`),
  CONSTRAINT `api_tema_conocimiento_tema_id_239195ef_fk_api_tema_id` FOREIGN KEY (`tema_id`) REFERENCES `api_tema` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_tema_conocimiento`
--

LOCK TABLES `api_tema_conocimiento` WRITE;
/*!40000 ALTER TABLE `api_tema_conocimiento` DISABLE KEYS */;
INSERT INTO `api_tema_conocimiento` VALUES (1,1,1),(2,1,2),(3,1,3),(4,2,4),(5,2,5),(6,2,6),(7,2,7),(8,2,8),(9,2,9),(10,3,10),(11,3,11),(12,3,12),(14,4,13),(15,4,14),(16,4,15),(13,4,16),(17,5,17),(18,5,18),(19,5,19),(20,6,20),(21,6,21),(22,7,22),(23,7,23),(24,8,24),(25,8,25),(26,8,26),(27,8,27),(39,12,39),(40,13,40),(41,14,41),(42,15,42),(43,16,43),(44,17,44),(45,18,45),(46,18,46),(47,18,47),(48,19,48),(49,19,49),(50,19,50),(51,20,51),(52,20,52),(53,21,54),(54,22,55),(55,23,56),(56,24,57),(57,25,58),(58,26,59),(59,27,60),(60,28,61),(61,29,62),(62,30,63),(63,31,64);
/*!40000 ALTER TABLE `api_tema_conocimiento` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-29 21:32:24
