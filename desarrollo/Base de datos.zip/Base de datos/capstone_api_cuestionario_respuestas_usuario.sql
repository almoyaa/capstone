-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: capstone
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `api_cuestionario_respuestas_usuario`
--

DROP TABLE IF EXISTS `api_cuestionario_respuestas_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_cuestionario_respuestas_usuario` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `cuestionario_id` int NOT NULL,
  `respuesta_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_cuestionario_respues_cuestionario_id_respuest_1480ab17_uniq` (`cuestionario_id`,`respuesta_id`),
  KEY `api_cuestionario_res_respuesta_id_b8e3bd8d_fk_api_respu` (`respuesta_id`),
  CONSTRAINT `api_cuestionario_res_cuestionario_id_a0e5314d_fk_api_cuest` FOREIGN KEY (`cuestionario_id`) REFERENCES `api_cuestionario` (`id`),
  CONSTRAINT `api_cuestionario_res_respuesta_id_b8e3bd8d_fk_api_respu` FOREIGN KEY (`respuesta_id`) REFERENCES `api_respuesta` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_cuestionario_respuestas_usuario`
--

LOCK TABLES `api_cuestionario_respuestas_usuario` WRITE;
/*!40000 ALTER TABLE `api_cuestionario_respuestas_usuario` DISABLE KEYS */;
INSERT INTO `api_cuestionario_respuestas_usuario` VALUES (89,10,1081),(90,10,1087),(86,10,1094),(87,10,1097),(88,10,1104),(99,11,1107),(102,11,1113),(106,11,1119),(92,11,1123),(94,11,1129),(96,11,1132),(98,11,1137),(101,11,1141),(104,11,1149),(91,11,1153),(93,11,1157),(95,11,1162),(97,11,1168),(100,11,1172),(103,11,1178),(105,11,1182),(108,12,1411),(107,12,1418),(111,13,1422),(114,13,1428),(116,13,1433),(118,13,1438),(109,13,1441),(110,13,1448),(112,13,1454),(113,13,1458),(115,13,1462),(117,13,1467);
/*!40000 ALTER TABLE `api_cuestionario_respuestas_usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-29 21:32:24
