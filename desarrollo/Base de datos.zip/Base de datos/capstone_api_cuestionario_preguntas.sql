-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: capstone
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `api_cuestionario_preguntas`
--

DROP TABLE IF EXISTS `api_cuestionario_preguntas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_cuestionario_preguntas` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `cuestionario_id` int NOT NULL,
  `pregunta_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_cuestionario_pregunt_cuestionario_id_pregunta_62078994_uniq` (`cuestionario_id`,`pregunta_id`),
  KEY `api_cuestionario_pre_pregunta_id_3938e1f8_fk_api_pregu` (`pregunta_id`),
  CONSTRAINT `api_cuestionario_pre_cuestionario_id_f0403b82_fk_api_cuest` FOREIGN KEY (`cuestionario_id`) REFERENCES `api_cuestionario` (`id`),
  CONSTRAINT `api_cuestionario_pre_pregunta_id_3938e1f8_fk_api_pregu` FOREIGN KEY (`pregunta_id`) REFERENCES `api_pregunta` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_cuestionario_preguntas`
--

LOCK TABLES `api_cuestionario_preguntas` WRITE;
/*!40000 ALTER TABLE `api_cuestionario_preguntas` DISABLE KEYS */;
INSERT INTO `api_cuestionario_preguntas` VALUES (91,10,217),(92,10,218),(93,10,219),(94,10,220),(95,10,221),(110,11,222),(111,11,223),(96,11,224),(97,11,225),(98,11,226),(99,11,227),(100,11,228),(101,11,229),(102,11,230),(103,11,231),(104,11,232),(105,11,233),(106,11,234),(107,11,235),(108,11,236),(109,11,237),(112,12,283),(113,12,284),(121,13,285),(122,13,286),(123,13,287),(114,13,288),(115,13,289),(116,13,290),(117,13,291),(118,13,292),(119,13,293),(120,13,294);
/*!40000 ALTER TABLE `api_cuestionario_preguntas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-29 21:32:24
