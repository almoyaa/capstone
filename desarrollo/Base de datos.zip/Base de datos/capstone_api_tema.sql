-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: capstone
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `api_tema`
--

DROP TABLE IF EXISTS `api_tema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_tema` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_tema`
--

LOCK TABLES `api_tema` WRITE;
/*!40000 ALTER TABLE `api_tema` DISABLE KEYS */;
INSERT INTO `api_tema` VALUES (1,'Números M1'),(2,'Álgebra y funciones M1'),(3,'Geometría M1'),(4,'Probabilidad y estadística M1'),(5,'Números M2'),(6,'Álgebra y funciones M2'),(7,'Geometría M2'),(8,'Probabilidad y estadística M2'),(12,'Localizar'),(13,'Interpretar'),(14,'Evaluar'),(15,'Cambios políticos, económicos, sociales y culturales del siglo XIX en Europa, América y Chile'),(16,'Chile durante el siglo XIX'),(17,'Europa, América y Chile durante la primera mitad del siglo XX'),(18,'Segunda mitad del siglo XX y el nuevo orden internacional después de la Segunda Guerra Mundial (Europa, América y Chile)'),(19,'Sociedad democrática'),(20,'Funcionamiento del sistema económico'),(21,'Organización, estructura y actividad celular'),(22,'Procesos y funciones biológicas'),(23,'Herencia y evolución'),(24,'Organismo y ambiente'),(25,'Ondas'),(26,'Mecánica'),(27,'Enería - Tierra'),(28,'Electricidad'),(29,'Estructura atómica'),(30,'Química orgánica'),(31,'Reacciones químicas y estequiometría');
/*!40000 ALTER TABLE `api_tema` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-29 21:32:24
