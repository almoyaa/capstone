-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: capstone
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `api_materia_tema`
--

DROP TABLE IF EXISTS `api_materia_tema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_materia_tema` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `materia_id` int NOT NULL,
  `tema_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_materia_tema_materia_id_tema_id_75379a50_uniq` (`materia_id`,`tema_id`),
  KEY `api_materia_tema_tema_id_e1cd525d_fk_api_tema_id` (`tema_id`),
  CONSTRAINT `api_materia_tema_materia_id_e065f124_fk_api_materia_id` FOREIGN KEY (`materia_id`) REFERENCES `api_materia` (`id`),
  CONSTRAINT `api_materia_tema_tema_id_e1cd525d_fk_api_tema_id` FOREIGN KEY (`tema_id`) REFERENCES `api_tema` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_materia_tema`
--

LOCK TABLES `api_materia_tema` WRITE;
/*!40000 ALTER TABLE `api_materia_tema` DISABLE KEYS */;
INSERT INTO `api_materia_tema` VALUES (1,1,1),(2,1,2),(3,1,3),(4,1,4),(6,2,5),(7,2,6),(8,2,7),(5,2,8),(12,4,12),(13,4,13),(14,4,14),(15,5,15),(16,5,16),(17,5,17),(18,5,18),(19,5,19),(20,5,20),(22,6,21),(23,6,22),(24,6,23),(21,6,24),(25,7,25),(26,7,26),(27,7,27),(28,7,28),(29,8,29),(30,8,30),(31,8,31);
/*!40000 ALTER TABLE `api_materia_tema` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-29 21:32:24
